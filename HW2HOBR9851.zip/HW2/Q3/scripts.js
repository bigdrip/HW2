function calC(c) {  
    //document.getElementById('panel').value += c;
    //$( 'panel' ).val() += c;
    //document.getElementById()
    //var c += $( "#panel" ).html.val();
    //var c$( "panel" ).html( "" + c + "");
    //c += $( "#panel" ).val();
    /*$( '#panel' ).val() + c;
    $("#test1").text(function(i, origText){
    return "Old text: " + origText + " New text: Hello world!
    (index: " + i + ")";
    });
    */
    $( "#panel" ).val(function( index, value ) {
      return value + c;
    });
     
    //$( "select" ).change( calC );
    // TODO: 3.1
    // This function does the evaluation for the calculator
    /*
    How this function would look if it were in Javascript would be:
    document.getElementById('panel').value += c;
    You need to convert the line above to JQuery.
    If you are writing more than a couple of lines of code, something is off. Check the reference links again
    */       

   
    
}
function CE() {
    // TODO: 3.2
    // This function performs the clear function
    // $( "#panel" ).val(function( index, value ) {
    //   return "";
    // });
    $( "#panel").val("");
    /*
    How this function would look if it were in Javascript would be:
    document.getElementById('panel').value = "";
    You need to convert the line above to JQuery.
    If you are writing more than a couple of lines of code, something is off. Check the reference links again
    */      

}

