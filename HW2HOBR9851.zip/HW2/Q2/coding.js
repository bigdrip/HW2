function display2_1() {
  // var saiyan = {name: 'Son Goku', age: 40};
  // console.log(saiyan.dragonball); //undefined
  // console.log(null == undefined); //true
  // console.log(null === undefined); //false

  // TODO 2.1: Fill in Answer here after the :
  var myanswer  = "My answer goes here:" + 
  "undefined (because 'dragonball' is not an assigned element of 'saiyan' undefined --> unassigned)" + 
  " 2 (abstract). true 3 (strict). false " +
   "(Since undefined --> unassigned --> assigned to NULL --> distinct types... the strict (===) will not work while the abstract (==) will still work.";  
  document.getElementById("21answer").innerHTML = myanswer; // Do not change
}
function display2_2() {
  var myanswer  = "My answer goes here: " + 
  "Since the 'use strict' makes the code beneath run in strict mode (which does not allow variable declarations and assignments in a single line of script) this will return false because x has not been previously decared and is supposed to be assigned a value, " +
  "however if strict is removed this will not cause an error because x is not declared inside a function and is not in strict mode." ;// TODO 2.2: Fill in Answer here
  document.getElementById("22answer").innerHTML = myanswer; // Do not change
}

function display2_5() {
  var myanswer  = "My answer goes here: " +
  "in the children of the id given we have a paragraph, a button, and a paragraph all of which are unviewible" +
  " the first paragraph and the button use the style;display class to change the display to invisible which is why we cant see it on the html page" +
  "the secon paragraph just contains an id and no values so it was not even called." +
  "even though these children are not displayed on the page, they still have value to the js file because they are defined in the HTML page." // TODO 2.5: Fill in Answer here
  document.getElementById("25answer").innerHTML = myanswer; // Do not change
}

function countDiv() { // Do not add or remove lines to this function
    var divs = document.getElementsByTagName('div'); // TODO: Question 2.3: Use the document Object to get the number of divs in the HTML page. Replace dummyMethod with the correct one.
    alert("Number of divs in this page is: " + divs.length); // Do not change 
}

function makeOrange() { // Do not add or remove lines to this function
    var narutos = document.getElementsByName("naruto"); // TODO: Question 2.4: Use the document Object to get all tags named "naruto" in the HTML page. Replace dummyMethod with the correct one.
    for(var i=0; i< narutos.length; i++) { // Do not change
        narutos[i].style.color = 'orange'; // Do not change
    }
}

function getChildrenTags() { // Do not add or remove lines to this function
  var children = document.getElementById("div_1134").children; // TODO: Question 2.5 Use the appropriate function to get all the children of a div named 'div_1134'
  console
  var tagNames = ""; // Do not change
  for (var i = 0; i < children.length; i++) {// Do not change
    console.log(children[i].tagName);// Do not change
    tagNames += children[i].tagName +", " ;// Do not change
  }// Do not change
  alert(children.length); // Do not change
  alert("The tags that I found are: " + tagNames);// Do not change
}

